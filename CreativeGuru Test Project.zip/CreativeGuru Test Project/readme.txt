1. SQL - Restore the database located in DB folder.
2. App - Change the server configuration / data source in connection string of web.config.
3. App - Set "creativegurus_test_project" as the startup project.

Default Admin/User:
Type: Admin
email: eric@test.com
password: @test123

Type: User
email: user@test.com
password: @Test123

Thanks & Cheers,
Eric Razon


