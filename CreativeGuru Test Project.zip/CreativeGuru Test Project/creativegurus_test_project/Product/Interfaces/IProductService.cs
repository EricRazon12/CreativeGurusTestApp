﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EProduct = Product.Entities.Product;

namespace Product.Interfaces
{
    public interface IProductService
    {
        IList<EProduct> GetProducts();
        EProduct AddProduct(EProduct product);
        bool UpdateProduct(EProduct product);
        bool DeleteProduct(EProduct product);
    }
}
