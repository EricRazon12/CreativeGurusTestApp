﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EProduct = Product.Entities.Product;

namespace Product.QueryObjects
{
    public class UpdateProduct : IQuery<bool>
    {
        private readonly EProduct _product;
        public UpdateProduct(EProduct product)
        {
            _product = product;
        }

        public bool Execute(IDbConnection conn)
        {
            var parms = new DynamicParameters();
            parms.Add(
                "@Id",
                _product.Id,
                dbType: DbType.Guid,
                direction: ParameterDirection.Input);
            parms.Add(
                "@ProductName",
                _product.ProductName,
                dbType: DbType.String,
                direction: ParameterDirection.Input);
            parms.Add(
                "@UnitPrice",
                _product.UnitPrice,
                dbType: DbType.String,
                direction: ParameterDirection.Input);

            return Convert.ToBoolean(conn.Query<int>("USP_UpdateProduct", parms, commandType: CommandType.StoredProcedure).FirstOrDefault());
        }
    }
}
