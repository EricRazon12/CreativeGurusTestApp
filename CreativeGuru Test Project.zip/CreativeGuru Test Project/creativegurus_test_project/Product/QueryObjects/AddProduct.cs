﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EProduct = Product.Entities.Product;

namespace Product.QueryObjects
{
    public class AddProduct : IQuery<EProduct>
    {
        private readonly EProduct _product;
        public AddProduct(EProduct product)
        {
            _product = product;
        }

        public EProduct Execute(IDbConnection conn)
        {
            var parms = new DynamicParameters();
            parms.Add(
                "@ProductName",
                _product.ProductName,
                dbType: DbType.String,
                direction: ParameterDirection.Input);
            parms.Add(
                "@UnitPrice",
                _product.UnitPrice,
                dbType: DbType.String,
                direction: ParameterDirection.Input);
            parms.Add(
               "@CategoryId",
               _product.CategoryId,
               dbType: DbType.Guid,
               direction: ParameterDirection.Input);

            return conn.Query<EProduct>("USP_AddProduct", parms, commandType: CommandType.StoredProcedure).FirstOrDefault();
        }
    }
}
