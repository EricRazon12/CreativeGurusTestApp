﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EProduct = Product.Entities.Product;

namespace Product.QueryObjects
{
    public class GetProducts : IQuery<IList<EProduct>>
    {

        public IList<EProduct> Execute(IDbConnection conn)
        {
            return conn.Query<EProduct>("USP_GetProducts").ToList();
        }
    }
}
