﻿using DataAccess;
using Product.Interfaces;
using Product.QueryObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EProduct = Product.Entities.Product;

namespace Product.Services
{
    public class ProductService : IProductService
    {
        private readonly IDatabase _db;
        public ProductService(IDatabase db)
        {
            _db = db;
        }

        public IList<EProduct> GetProducts()
        {
            return _db.Query(new GetProducts());
        }

        public EProduct AddProduct(EProduct product)
        {
            return _db.Query(new AddProduct(product));
        }

        public bool UpdateProduct(EProduct product)
        {
            return _db.Query(new UpdateProduct(product));
        }

        public bool DeleteProduct(EProduct product)
        {
            return _db.Query(new DeleteProduct(product));
        }
    }
}
