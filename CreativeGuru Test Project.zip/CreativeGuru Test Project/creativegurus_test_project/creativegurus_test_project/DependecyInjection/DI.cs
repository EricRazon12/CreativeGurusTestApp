﻿using Autofac;
using Category.Interfaces;
using Category.Services;
using DataAccess;
using Product.Interfaces;
using Product.Services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace creativegurus_test_project.DependecyInjection
{
    public class DI
    {
        public ContainerBuilder OnConfigure(ContainerBuilder builder)
        {

            builder.Register(x => { return new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString()); }).As(typeof(IDbConnection)).InstancePerRequest();
            builder.RegisterType<Database>().As(typeof(IDatabase)).InstancePerLifetimeScope();
            builder.RegisterType<ProductService>().As(typeof(IProductService)).InstancePerLifetimeScope();
            builder.RegisterType<CategoryService>().As(typeof(ICategoryService)).InstancePerLifetimeScope();
            return builder;
        }
    }
}