﻿using Autofac;
using Autofac.Integration.Mvc;
using Autofac.Integration.WebApi;
using creativegurus_test_project.DependecyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace creativegurus_test_project
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AutofacConfigure();
        }

        protected void Application_BeginRequest()
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
        }

        public IContainer myContainer { get; set; }

        public void AutofacConfigure()
        {
            var di = new DI();

            ContainerBuilder builder = new ContainerBuilder();

            builder = di.OnConfigure(builder);

            //This is where you register all dependencies
            //The line below tells autofac, when a controller is initialized, pass into its constructor, the implementations of the required interfaces
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            if (this.myContainer == null)
            {

                this.myContainer = builder.Build();
            }
            else
            {
                builder.Update(this.myContainer);
            }

            DependencyResolver.SetResolver(new AutofacDependencyResolver(this.myContainer));

            GlobalConfiguration.Configuration.DependencyResolver = new AutofacWebApiDependencyResolver(this.myContainer);
        }
    }
}
