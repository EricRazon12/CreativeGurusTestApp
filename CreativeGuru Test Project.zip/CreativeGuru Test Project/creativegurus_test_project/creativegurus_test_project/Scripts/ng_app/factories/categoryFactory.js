﻿var categoryUri = "/api/Category/";
categoryServices.$inject = ['$http'];
angular.module('category.factory.module', [])
.factory('categoryFactory', categoryServices);

function categoryServices($http) {
    return {
        GetAll: function () {
            return $http({
                method: 'GET',
                url: categoryUri + 'GetCategories',
                contentType: "application/json"
            });
        },
        AddCategory: function (category) {
            return $http({
                    method: 'POST',
                    url: categoryUri + 'AddCategory',
                    contentType: "application/json",
                    data: category
                });
        },
        UpdateCategory: function (category) {
            return $http({
                method: 'PUT',
                url: categoryUri + 'UpdateCategory',
                contentType: "application/json",
                data: category
            });
        }
    }
}