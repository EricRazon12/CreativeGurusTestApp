﻿var productUri = "/api/Product/";
productServices.$inject = ['$http'];
angular.module('product.factory.module', [])
.factory('productFactory', productServices);

function productServices($http) {
    return {
        GetAll: function () {
            return $http({
                method: 'GET',
                url: productUri + 'GetProducts',
                contentType: "application/json"
            });
        },
        AddProduct: function (product) {
            return $http({
                method: 'POST',
                url: productUri + 'AddProduct',
                contentType: "application/json",
                data: product
            });
        },
        UpdateProduct: function (product) {
            return $http({
                method: 'PUT',
                url: productUri + 'UpdateProduct',
                contentType: "application/json",
                data: product
            });
        },
        DeleteProduct: function (product) {
            return $http({
                method: 'Delete',
                url: productUri + 'DeleteProduct',
                contentType: "application/json",
                params: { Id: product.Id }
            });
        }
    }
}