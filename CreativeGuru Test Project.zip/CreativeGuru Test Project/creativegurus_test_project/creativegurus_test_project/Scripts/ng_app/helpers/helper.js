﻿helperServices.$inject = [];
angular.module('app.helper.module', [])
.factory('helperFactory', helperServices);

function helperServices() {
    return {
        GetIndex: function (list, column, id) {
            var index = -1;
            for (var x = 0; x < list.length; x++) {
                if (list[x][column] == id) {
                    index = x;
                }
            }
            return index;
        },
        GetIndexes: function (list, column, id) {
            var indexes = [];
            for (var x = 0; x < list.length; x++) {
                if (list[x][column] == id) {
                    indexes.push(x);
                }
            }
            return indexes;
        }
    }
}