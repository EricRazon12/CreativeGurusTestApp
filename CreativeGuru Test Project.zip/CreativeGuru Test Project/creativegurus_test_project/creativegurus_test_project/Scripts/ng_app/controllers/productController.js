﻿fnController.$inject = ['$scope', '$window', 'productFactory', 'helperFactory'];
angular.module('product.controller.module', ['product.factory.module', 'app.helper.module'])
    .controller('productController', fnController)
function fnController($scope, $window, productFactory, helperFactory) {
    $scope.orderByField = 'CategoryName';
    $scope.reverseSort = false;

    $scope.product = {
        list: '',
        item: {},
        clientFunction: {
            getProduct: function (product) {
                $scope.product.item = angular.copy(product);
            }
        },
        serverFunction: {
            getAll: function () {
                productFactory.GetAll()
                .then(function (response) {
                    $scope.product.list = response.data;
                    //console.log($scope.product.list);
                }, function (err) {

                });
            },
            addProduct: function (product) {
                productFactory.AddProduct(product)
                    .then(function (response) {
                        if (response.data.Id != undefined) {
                            $scope.product.list.push(response.data);
                            $('#addProduct').modal('toggle');
                        }
                    }, function (err) {

                    });
            },
            updateProduct: function (product, isTouched) {
                if (isTouched) {
                    productFactory.UpdateProduct(product)
                    .then(function (response) {
                        if (response.data) {
                            $scope.product.list[helperFactory.GetIndex($scope.product.list, "Id", product.Id)] = product;
                            $('#updateProduct').modal('toggle');
                            $scope.product.item = {};
                        }
                    }, function (err) {
                        console.log(err);
                    });
                } else {
                    $('#updateProduct').modal('toggle');
                }
            },
            deleteProduct: function (product) {
                if (confirm('Do yo want to delete this product?'))
                {
                    productFactory.DeleteProduct(product)
                    .then(function (response) {
                        if (response.data) {
                            $scope.product.list.splice(helperFactory.GetIndex($scope.product.list, "Id", product.Id), 1);
                        }
                    }, function (err) {

                    });
                }
            }
        }
        
    }

    
}