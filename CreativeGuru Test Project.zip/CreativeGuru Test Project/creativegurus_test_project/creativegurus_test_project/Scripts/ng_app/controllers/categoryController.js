﻿fnController.$inject = ['$rootScope', '$scope', '$window', 'categoryFactory', 'helperFactory'];
angular.module('category.controller.module', ['category.factory.module', 'app.helper.module'])
    .controller('categorytController', fnController)
function fnController($rootScope, $scope, $window, categoryFactory, helperFactory) {
    $scope.category = {
        list: '',
        item: {},
        itemEdit: {},
        clientFunction: {
            getCategory: function (category) {
                $scope.category.itemEdit = angular.copy(category);
                $scope.category.flag.isEdit = !$scope.category.flag.isEdit;
            }
        },
        serverFunction: {
            getAll: function () {
                categoryFactory.GetAll()
                .then(function (response) {
                    $scope.category.list = response.data;
                    //console.log($scope.category.list);
                }, function (err) {

                });
            },
            addCategory: function (category) {
                categoryFactory.AddCategory(category)
                .then(function (response) {
                    if (response.data.CategoryId != undefined) {
                        $scope.category.list.push(response.data);
                        $scope.category.item = {};
                        $('#addCategory').modal('toggle');
                    }
                }, function (err) {

                });
            },
            updateCategory: function (category) {
                categoryFactory.UpdateCategory(category)
                .then(function (response) {
                    if (response.data) {
                        $scope.category.list[helperFactory.GetIndex($scope.category.list, "CategoryId", category.CategoryId)] = category;
                        var categoryIndexList = helperFactory.GetIndexes($rootScope.product.list, "CategoryId", category.CategoryId);
                        for(var x = 0; x < categoryIndexList.length; x++){
                            $rootScope.product.list[categoryIndexList[x]].CategoryName = category.CategoryName;
                        }
                        $scope.category.flag.isEdit = !$scope.category.flag.isEdit;
                    }
                }, function (err) {

                });
            }
        },
        flag: {
            isEdit: false
        }
    }
  
}