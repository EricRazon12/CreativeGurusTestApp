﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace creativegurus_test_project.Controllers
{
    [Authorize(Roles = "User")]
    public class UserController : Controller
    {
        public ActionResult Products()
        {
            return View();
        }
    }
}