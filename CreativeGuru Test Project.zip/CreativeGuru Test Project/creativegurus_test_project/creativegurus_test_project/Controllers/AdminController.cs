﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace creativegurus_test_project.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        public ActionResult Products()
        {
            return View();
        }

        public ActionResult Category()
        {
            return View();
        }
    }
}