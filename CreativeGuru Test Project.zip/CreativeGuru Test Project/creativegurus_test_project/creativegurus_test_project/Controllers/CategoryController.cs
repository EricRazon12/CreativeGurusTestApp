﻿using Category.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ECategory = Category.Entities.Category;

namespace creativegurus_test_project.Controllers
{
    public class CategoryController : ApiController
    {
        private readonly ICategoryService _categoryService;
        public CategoryController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public IList<ECategory> GetCategories()
        {
            return _categoryService.GetCategories();
        }

        [HttpPost]
        public ECategory AddCategory([FromBody]ECategory category)
        {
            return _categoryService.AddCategory(category);
        }

        [HttpPut]
        public bool UpdateCategory([FromBody]ECategory category)
        {
            return _categoryService.UpdateCategory(category);
        }
    }
}
