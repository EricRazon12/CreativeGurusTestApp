﻿using Product.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EProduct = Product.Entities.Product;

namespace creativegurus_test_project.Controllers
{
    public class ProductController : ApiController
    {
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        public IList<EProduct> GetProducts()
        {
            return _productService.GetProducts();
        }

        [HttpPost]
        public EProduct AddProduct([FromBody]EProduct product)
        {
            return _productService.AddProduct(product);
        }

        [HttpPut]
        public bool UpdateProduct([FromBody]EProduct product)
        {
            return _productService.UpdateProduct(product);
        }

        [HttpDelete]
        public bool DeleteProduct(Guid id)
        {
            EProduct product = new EProduct()
            {
                Id = id
            };
            return _productService.DeleteProduct(product);
        }
    }
}
