﻿using Category.Interfaces;
using Category.QueryObjects;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECategory = Category.Entities.Category;

namespace Category.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly IDatabase _db;
        public CategoryService(IDatabase db)
        {
            _db = db;
        }

        public IList<ECategory> GetCategories()
        {
            return _db.Query(new GetCategories());
        }

        public ECategory AddCategory(ECategory category)
        {
            return _db.Query(new AddCategory(category));
        }

        public bool UpdateCategory(ECategory category)
        {
            return _db.Query(new UpdateCategory(category));
        }
    }
}
