﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECategory = Category.Entities.Category;

namespace Category.Interfaces
{
    public interface ICategoryService
    {
        IList<ECategory> GetCategories();
        ECategory AddCategory(ECategory category);
        bool UpdateCategory(ECategory category);
    }
}
