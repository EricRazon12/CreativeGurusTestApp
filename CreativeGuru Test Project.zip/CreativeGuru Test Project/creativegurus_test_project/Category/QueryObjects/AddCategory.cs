﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECategory = Category.Entities.Category;

namespace Category.QueryObjects
{
    public class AddCategory : IQuery<ECategory>
    {
        private readonly ECategory _category;
        public AddCategory(ECategory category)
        {
            _category = category;
        }

        public ECategory Execute(IDbConnection conn)
        {
            var parms = new DynamicParameters();
            parms.Add(
                "@CategoryName",
                _category.CategoryName,
                dbType: DbType.String,
                direction: ParameterDirection.Input);

            return conn.Query<ECategory>("USP_AddCategory", parms, commandType: CommandType.StoredProcedure).FirstOrDefault();
        }
    }
}
