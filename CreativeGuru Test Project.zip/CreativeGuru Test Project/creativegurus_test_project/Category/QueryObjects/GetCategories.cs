﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECategory = Category.Entities.Category;

namespace Category.QueryObjects
{
    public class GetCategories : IQuery<IList<ECategory>>
    {
        public IList<ECategory> Execute(IDbConnection conn)
        {
            return conn.Query<ECategory>("USP_GetCategories").ToList();
        }
    }
}
