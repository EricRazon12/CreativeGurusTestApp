﻿using Dapper;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ECategory = Category.Entities.Category;

namespace Category.QueryObjects
{
    public class UpdateCategory : IQuery<bool>
    {
        private readonly ECategory _category;
        public UpdateCategory(ECategory category)
        {
            _category = category;
        }

        public bool Execute(IDbConnection conn)
        {
            var parms = new DynamicParameters();
            parms.Add(
                "@CategoryId",
                _category.CategoryId,
                dbType: DbType.Guid,
                direction: ParameterDirection.Input);
            parms.Add(
                "@CategoryName",
                _category.CategoryName,
                dbType: DbType.String,
                direction: ParameterDirection.Input);

            return Convert.ToBoolean(conn.Query<int>("USP_UpdateCategory", parms, commandType: CommandType.StoredProcedure).FirstOrDefault());
        }
    }
}
