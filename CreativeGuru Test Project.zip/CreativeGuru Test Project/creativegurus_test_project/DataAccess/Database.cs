﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class Database : IDatabase, IDisposable
    {
        private IDbConnection _conn;

        public Database(IDbConnection conn)
        {
            _conn = conn;
        }

        public IDbConnection Connection
        {
            get
            {
                if (_conn.State == ConnectionState.Closed)
                {
                    _conn.Open();
                }

                return _conn;
            }
            set
            {
                this.Connection = value;
            }
        }

        public void Execute(ICommand command)
        {
            command.Execute(_conn);
        }

        public T Query<T>(IQuery<T> query)
        {
            return query.Execute(_conn);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_conn.State == ConnectionState.Open)
                {
                    _conn.Close();
                    _conn.Dispose();
                }

                _conn = null;
            }
        }
    }
}
